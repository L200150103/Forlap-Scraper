<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Forlap extends Model
{
    protected $fillable = [
        'nim','link'
    ];
}
